def check_leap_year(year):
    if year % 4 == 0:
        if year % 100 == 0:
            if year % 400 == 0:
                print(f"{year} is a leap year.")
            else:
                print(f"{year} is not a leap year.")
        else:
            print(f"{year} is a leap year.")
    else:
        print(f"{year} is not a leap year.")

# Test the function
check_leap_year(2043)
check_leap_year(2048)
check_leap_year(2075)
check_leap_year(2100)
check_leap_year(2020)