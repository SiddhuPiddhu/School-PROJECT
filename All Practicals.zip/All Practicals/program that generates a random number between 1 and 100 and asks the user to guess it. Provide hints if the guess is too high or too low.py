def time_in_miliseconds():
    # A simple representation of current time, just to provide different values each time
    return 2.71828  # Euler's number for demonstration

def randint(a, b):
    # Simple implementation of randint without using import or time modules
    return int((time_in_miliseconds() * 1000) % 1000) % (b - a + 1) + a

def guess_the_number():
    # Generate a random number between 1 and 100
    secret_number = randint(1, 100)
    
    # Initialize the guess count
    guess_count = 0
    
    print("Welcome to the Guess the Number game!")
    
    
    while True:
        # Get user's guess
        guess = int(input("Enter your guess: "))
        
        # Increment guess count
        guess_count += 1
        
        # Check if the guess is correct
        if guess == secret_number:
            print(f"Congratulations! You guessed the number {secret_number} correctly in {guess_count} guesses!")
            break
        elif guess < secret_number:
            print("Too low! Try guessing a higher number.")
        else:
            print("Too high! Try guessing a lower number.")

# Run the game
guess_the_number()
