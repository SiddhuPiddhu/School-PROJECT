a=input("enter a sentence:")
b=a.split()
c=len(b)
print(c)