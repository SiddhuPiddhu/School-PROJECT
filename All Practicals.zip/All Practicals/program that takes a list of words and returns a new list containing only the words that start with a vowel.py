def starts_with_vowel(word):
    vowels = ['a', 'e', 'i', 'o', 'u']
    return word[0].lower() in vowels

words = input("Enter a list of words, separated by spaces: ").split()
vowel_words = [word for word in words if starts_with_vowel(word)]

print(vowel_words)