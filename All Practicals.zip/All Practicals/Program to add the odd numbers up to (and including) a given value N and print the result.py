n=int(input("enter a positive integer:"))
sum_odd_numbers= sum(range(1,n+1,2))
print("the sum of odd numbers up to ",n, "is: ", sum_odd_numbers)
