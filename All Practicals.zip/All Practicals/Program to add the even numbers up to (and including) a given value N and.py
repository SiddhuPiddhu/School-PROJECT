n=int(input("enter a positive number n:"))
sum_even_no=0
for i in range(2,n+1,2):
    sum_even_no+=i
print("the sum of all even numbers from 1 to",n,"is",sum_even_no)