p=int(input("enter your principle amount"))
r=int(input("enter your rate of interest"))
t=int(input("Enter your time"))
print("your simple interest",(p*r*t)/100)
