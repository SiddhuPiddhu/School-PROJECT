numbers = []
total = 0

while True:
    number = input("Enter a number: ")

    if number.lower() == "done":
        break

    if number.strip().isdigit():
        number = float(number)
        numbers.append(number)
        total += number
    else:
        print("Invalid input. Please enter a number.")

if numbers:
    average = total / len(numbers)
    print("The average of the numbers you entered is: ", average)
else:
    print("No valid numbers were entered.")
