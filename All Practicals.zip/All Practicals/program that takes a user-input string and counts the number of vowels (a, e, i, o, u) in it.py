# Input a string from the user
user_input = input("Enter a string: ")

# Define a string containing vowels
vowels = "aeiouAEIOU"

# Count the number of vowels in the input string
vowel_count = sum(1 for char in user_input if char in vowels)

print("Number of vowels:", vowel_count)
