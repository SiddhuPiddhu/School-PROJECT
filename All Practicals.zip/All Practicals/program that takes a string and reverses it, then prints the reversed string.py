def reverse_string(input_string):
    reversed_string = input_string[::-1]
    print(f"Reversed string: {reversed_string}")

# Test the function
input_string = input("Enter a string: ")
reverse_string(input_string)
