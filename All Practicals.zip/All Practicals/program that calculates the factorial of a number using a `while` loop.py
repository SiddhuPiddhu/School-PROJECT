a=int(input("enter a number"))
b=1
i=1
while i <= a:
    b=b*i
    i=i+1
print("factorial of",a,"is", b)