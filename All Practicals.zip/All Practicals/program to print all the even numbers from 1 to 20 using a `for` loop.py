for num in range(2,21,2):
    print(num)