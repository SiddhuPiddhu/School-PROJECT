t = ()
n = int(input('Enter the total entries of students : '))
for i in range(n):
    name = input('Enter the name : ')
    tm = int(input('Total marks (out of 500) : '))
    avg = tm/5
    st = (name,tm,avg)
    t += (st,)
print(t)
#P48 (a)
for j in t:
    if j[2] >= 33:
        j += ('Pass',)
        print('Candidate',j[0],'is pass')
    elif j[2] < 33:
        j += ('Fail',)
        print('Candidate',j[0],'is fail')
#P48(b)
a = input('Enter the name to be searched : ')
for k in t:
    if a == k[0]:
        print('Total marks =',k[1])
        print('Average =',k[2])
        if k[2] >= 33:
            print('Result = Pass')
        elif k[2] < 33:
            print('Result = Fail')
        break
else:
    print('Name not found')
#P48(c)
print('Name\t\t','Total Marks\t','Average')
for l in t:
    print(l[0],l[1],l[2],end = '\t\t')
#P48(d)
print('Excellent performing students')
for m in t:
    if m[2] >= 75:
        print(m[0])