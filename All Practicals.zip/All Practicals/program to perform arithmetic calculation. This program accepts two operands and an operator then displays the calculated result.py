# Take input from the user
num1 = int(input("Enter first number: "))
operator = input("Enter operator : ")
num2 = int(input("Enter second number: "))

# Perform calculation based on operator
if operator == "+":
    result = num1 + num2
elif operator == "-":
    result = num1 - num2
elif operator == "*":
    result = num1 * num2
elif operator == "/":
    result = num1 / num2
else:
    print("Invalid operator")
    result = None

# Display the result
if result is not None:
    print(f"The result is {result}")