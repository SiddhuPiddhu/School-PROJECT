a=int(input("enter side one"))
b=int(input("enter side two"))
print("area of rectangle",a*b)
print("perimeter of rectangle",2*(a+b))