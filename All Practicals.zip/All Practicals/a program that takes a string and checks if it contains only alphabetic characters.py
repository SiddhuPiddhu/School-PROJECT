def check_alphabetical(string):
    for char in string:
        if not char.isalpha():
            return False
    return True

string = input("Enter a string: ")
if check_alphabetical(string):
    print("The string contains only alphabetical characters.")
else:
    print("The string contains characters other than alphabets.")