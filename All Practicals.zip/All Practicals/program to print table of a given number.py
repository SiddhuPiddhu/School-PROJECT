def print_table(num):
    for i in range(1, 11):
        print(num, "x", i, "=", num*i)

# Ask the user to enter a number
num = int(input("Enter a number: "))

# Print the table of the given number
print_table(num)