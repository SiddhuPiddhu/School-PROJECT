
# Input a list of numbers from the user
numbers_str = input("Enter a list of numbers separated by spaces: ")

# Convert the input string into a list of integers
numbers = [int(num) for num in numbers_str.split()]

sorted_numbers = sorted(numbers)
length = len(sorted_numbers)

if length % 2 == 0:
    middle_left = sorted_numbers[length // 2 - 1]
    middle_right = sorted_numbers[length // 2]
    median = (middle_left + middle_right) / 2
else:
    median = sorted_numbers[length // 2]

print("Median:", median)
