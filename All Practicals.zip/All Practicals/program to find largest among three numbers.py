a=int(input("enter your first number"))
b=int(input("enter your second number"))
c=int(input("enter your third number"))
if (a>b) and (a>c):
    print("number 1 is largest",a)
elif(b>a) and (b>c):
    print("number 2 is largest",b)
else:
    print("number 3 is largest",c)