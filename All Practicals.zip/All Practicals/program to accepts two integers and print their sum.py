a=int(input("enter your first number"))
b=int(input("enter your second number"))
print(a+b)