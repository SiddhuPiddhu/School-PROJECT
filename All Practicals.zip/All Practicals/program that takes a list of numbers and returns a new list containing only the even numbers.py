
numbers_str = input("Enter a list of number: ")
numbers_str_list = numbers_str.split(',')
even_numbers = []
for num_str in numbers_str_list:
    num = int (num_str)
    if num % 2 == 0:
        even_numbers.append(num)
print("The even numbers are:", even_numbers)