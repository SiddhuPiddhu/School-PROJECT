def fibonacci(n):
    a, b = 0,1
    while a < n:
        print(a, end=' ')
        a, a = b, a+b
    print()
num = int(input("enter any number"))
fibonacci(num)