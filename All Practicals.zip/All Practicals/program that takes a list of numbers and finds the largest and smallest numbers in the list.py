def find_largest_and_smallest(numbers):
    smallest = numbers[0]
    largest = numbers[0]
    for num in numbers:
        if num < smallest:
            smallest = num
        if num > largest:
            largest = num
    print("The smallest number is:", smallest)
    print("The largest number is:", largest)
numbers=[3,4,5,6,7,8]
find_largest_and_smallest(numbers)