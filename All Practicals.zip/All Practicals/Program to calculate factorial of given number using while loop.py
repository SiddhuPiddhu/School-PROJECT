def factorial(n):
    result = n
    while n > 1:
        result *= (n-1)
        n -= 1
    result *= n
    return result

num = int(input("enter the number"))
print("The factorial of", num, "is", factorial(num))