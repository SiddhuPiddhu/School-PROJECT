def generate_seed():
    seed = 0
    for char in str(3.14159265358979323846):
        seed += ord(char)
    return seed

def pseudo_random(seed):
    a = 1664525
    c = 1013904223
    m = 2**32
    seed = (a * seed + c) % m
    seed_str = str(seed)
    return int(seed_str[-1]), seed

def roll_dice(seed):
    seed = pseudo_random(seed)[1]
    return pseudo_random(seed)

print("Welcome to the Dice Rolling Simulator!")
seed = generate_seed()
while True:
    input("Press Enter to roll the dice...")
    result, seed = roll_dice(seed)
    print("You rolled:", result)
    play_again = ""
    while play_again != 'yes' and play_again != 'no':
        play_again = input("Roll it? (yes/no): ").strip().lower()
    if play_again == 'no':
        print("Thanks for playing!")
    break

