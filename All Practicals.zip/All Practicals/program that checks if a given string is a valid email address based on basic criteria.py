def is_valid_email(email):
    parts = email.split('@')
    return (len(parts) == 2 and
            '.' in parts[1] and
            all(c.isalnum() or c in ['.', '_', '%', '+', '-'] for c in parts[0]) and
            all(c.isalnum() or c in ['.', '-'] for c in parts[1]))

# Example usage:
email = input("Enter an email address: ")
print("Valid email address" if is_valid_email(email) else "Invalid email address")
