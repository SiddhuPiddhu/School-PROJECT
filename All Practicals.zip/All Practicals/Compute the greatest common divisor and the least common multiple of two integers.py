# Function to compute GCD and LCM
def compute_gcd_lcm(a, b):
    # Compute GCD
    while b != 0:
        a, b = b, a % b
    gcd = a
    # Compute LCM
    if a == 0 or b == 0:
        lcm = 0
    else:
        lcm = abs(a * b) // gcd
    # Print GCD and LCM
    print("GCD:", gcd)
    print("LCM:", lcm)

# Example usage
compute_gcd_lcm(8, 6)