a=int(input("enter a number:"))
s=0
for i in range(0,a+1):
    if (i%2)==0:
        print(i)
        s+=i
print("sum is",s)