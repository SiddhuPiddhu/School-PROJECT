numbers = list(eval(input("Enter list of no seperated by comma")))
fibonacci_numbers = [0, 1]
for i in range(2, max(numbers)):
    next_number = fibonacci_numbers[i-1] + fibonacci_numbers[i-2]
    if next_number > max(numbers):
        break
    fibonacci_numbers.append(next_number)
result = []
for number in numbers:
    if number in fibonacci_numbers:
        result.append(number)
print(result)
