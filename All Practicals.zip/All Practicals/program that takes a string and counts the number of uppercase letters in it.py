count_uppercase=input("enter any word")  
count = 0
for c in count_uppercase:
        if c.isupper():
            count+=1
print(count)
