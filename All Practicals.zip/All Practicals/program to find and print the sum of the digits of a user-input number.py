num = input("Enter a number: ")
sum = 0
for i in num:
    sum += int(i)
print("Sum of digits:", sum)