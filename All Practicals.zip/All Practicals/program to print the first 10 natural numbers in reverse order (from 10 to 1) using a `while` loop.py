count = 10  # start with 10

while count >= 1:  # loop while count is greater than or equal to 1
    print(count)  # print the current number
    count -= 1  # decrease the count by 1