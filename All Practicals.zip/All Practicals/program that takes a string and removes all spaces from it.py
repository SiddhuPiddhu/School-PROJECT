s = input("Enter a string: ")
s=s.replace(' ','')
print(s)