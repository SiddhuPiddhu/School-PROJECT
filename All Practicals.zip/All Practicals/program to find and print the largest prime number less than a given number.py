largest_prime = -1
for i in range(int(input("Enter a number ")), 0, -1):
    for j in range(i,2):
        if i % j == 0:
            break
    else:
        largest_prime = i
        break

print("The largest prime number less than", int(input("Enter a number: ")), "is", largest_prime)