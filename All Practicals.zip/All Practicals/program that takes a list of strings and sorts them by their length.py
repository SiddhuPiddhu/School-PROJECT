def Sorting(lst):
    lst.sort(key=len)
    return lst

def main():
    # Take input from the user
    input_string = input("Enter a list of strings separated by commas: ")
    
    # Split the input string into a list of strings
    strings = [s.strip() for s in input_string.split(',')]
    
    # Sort the list of strings by their length
    sorted_strings = Sorting(strings)
    
    # Print the sorted list
    print("Sorted strings by length:")
    for s in sorted_strings:
        print(s)

if __name__ == "__main__":
    main()

