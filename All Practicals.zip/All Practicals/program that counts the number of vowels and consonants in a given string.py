def count_vowels_consonants(s):
    vowels = "aeiou"
    consonants = "cdfghjklmnpqrstvwxyz"
    vowel_count = 0
    consonant_count = 0

    for char in s:
        if char.lower() in vowels:
            vowel_count += 1
        elif char.lower() in consonants:
            consonant_count += 1

    return vowel_count, consonant_count

string = input("Enter a string: ")
vowel_count, consonant_count = count_vowels_consonants(string)

print("Number of vowels: ", vowel_count)
print("Number of consonants: ", consonant_count)