def sum_of_cubes(n, sum):
    while n > 0:
        digit = n % 10
        sum += digit ** 3
        n = n // 10
    return sum

def is_sum_of_cubes(n):
    sum = 0
    if n == sum_of_cubes(n, sum):
        print(n, "is equal to the sum of the cubes of its digits.")
    else:
        print(n, "is not equal to the sum of the cubes of its digits.")
num = int(input("enter any number"))
is_sum_of_cubes(num)