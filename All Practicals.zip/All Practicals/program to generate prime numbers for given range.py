def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def generate_prime(start, end):
    prime = []
    for num in range(start, end + 1):
        if all(num % i != 0 for i in range(2, int(num**0.5) + 1)):
            prime.append(num)
    return prime

start_range = int(input("Enter the start of the range: "))
end_range = int(input("Enter the end of the range: "))

prime = generate_prime(start_range, end_range)
print("Prime numbers in the given range: ", prime)