def replace_char(old_char, new_char): 
    return string.replace(old_char, new_char)

string = input("Enter a string: ")
old_char = input("Enter the character to replace: ")
new_char = input("Enter the new character: ")

new_string = replace_char( old_char, new_char)

print(new_string)