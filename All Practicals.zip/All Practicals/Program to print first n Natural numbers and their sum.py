def print_natural_numbers_and_sum(n):
    sum = 0
    for i in range(1, n+1):
        sum += i
        print(i)
    print("The sum of the first", n, "natural numbers is:", sum)

# Ask the user to enter a number
n = int(input("Enter a number: "))

# Print the first n natural numbers and their sum
print_natural_numbers_and_sum(n)