a=int(input("enter your number"))
if a%2==0:
    print("your number is even")
else:
    print("your number is odd")