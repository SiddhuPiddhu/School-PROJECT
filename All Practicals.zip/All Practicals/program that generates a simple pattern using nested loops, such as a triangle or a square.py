#alphabet pattern
'''row =int(input("number of pattern you want"))
for i in range(row):
    for j in range(i+1):
        print(chr(ord('A')+i), end='')
    print()'''


#star pattern
'''row=int(input("number of pattern you want"))
for i in range(row):
    for j in range(i+1):
        print("*", end="")
    print()'''


#number pattern
row=int(input("enter number of pattern"))
for i in range(1,row+1):
    for j in range(i,0,-1):
        print(j,end="")
    print()