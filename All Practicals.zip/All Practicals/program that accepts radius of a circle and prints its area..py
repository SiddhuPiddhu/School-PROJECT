a=int(input("enter your radius"))
print("area of circle",3.14*a**2)