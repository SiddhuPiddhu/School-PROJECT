string = input("Enter a string: ")
if string == string[::-1]:
   print("it is a pallindrome")
else:
   print("it is not a pallindrome")